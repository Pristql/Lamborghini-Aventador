# Lamborghini Aventador

A Pen created on CodePen.

Original URL: [https://codepen.io/Blockblaster/pen/OPMaLWb](https://codepen.io/Blockblaster/pen/OPMaLWb).

